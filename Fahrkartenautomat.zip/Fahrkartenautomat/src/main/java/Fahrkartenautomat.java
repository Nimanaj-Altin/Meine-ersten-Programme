//imports
import java.util.Scanner;

//programmname
public class Fahrkartenautomat {

//hauptprogramm -whileSchleife- 
    public static void main(String[] args) {
        int x = 1;
            
        while(x==1){
            aufnahmeDerDaten();
        }
    }
        
//methode der aufnahmedaten -Methode- u. -ifSchleifen-
    private static void aufnahmeDerDaten(){
        
        
        Scanner tastatur = new Scanner(System.in);
            
        
        double zuZahlenderBetrag;
        double eingegebeneArtTicket;
            
        
        System.out.println("Willkommen bei dem BVG-Automaten");
        System.out.println("Wählen Sie ihre Wunschfahrkarte für Berlin AB aus: \n "
                + "einzelfahrschein Regeltarf AB [2,90€] (drücken Sie dafür die 1) \n "
                + "Tageskarte Regeltarif AB [8,60€] (drücken Sie dafür die 2) \n"
                + "Kleingruppen-Tageskarte Regeltarif AB [23,50€] (drücken Sie dafür die 3) \n");
        
        zuZahlenderBetrag = tastatur.nextDouble();
        
        if (zuZahlenderBetrag == 1){
            System.out.println("Ihre Wahl ist ein einzelfahrschein Regeltarf AB für 2.90");
            System.out.println("Wie vile dieser Tickets möchten Sie gdrucken? Bitte angeben \n");
                
            eingegebeneArtTicket = tastatur.nextInt();
            
            geldeinwurf(2.90 , eingegebeneArtTicket);
            
            fahrscheinausgabe(); 
        }
        
        if (zuZahlenderBetrag == 2){
            System.out.println("Ihre Wahl ist ein Tageskarte Regeltarif AB für 8,60€ ");
            System.out.println("Wie vile dieser Tickets möchten Sie gdrucken? Bitte angeben} \n");
                
            eingegebeneArtTicket = tastatur.nextInt();
            
            geldeinwurf(8.60 , eingegebeneArtTicket);
            
            fahrscheinausgabe();
        }
        
        if (zuZahlenderBetrag == 3){
            System.out.println("Kleingruppen-Tageskarte Regeltarif AB für 23,50€");
            System.out.println("Wie vile dieser Tickets möchten Sie gdrucken? Bitte angeben \n");
                
            eingegebeneArtTicket = tastatur.nextInt();
            
            geldeinwurf(23.50 , eingegebeneArtTicket);
            
            fahrscheinausgabe();  
        }
        
        if (zuZahlenderBetrag >= 4){
            System.out.println("Sie haben keine der entsprächenden fahrkarten Nummern gennant (1 , 2 , 3) \n "
                    + "Sie kommen zum Hauptmenü zurück \n");
            
            for (int i = 0; i < 8; i++){
                            
                System.out.print("=");
                try{
                    Thread.sleep(250);
                }
                catch (InterruptedException e){
                    e.printStackTrace();
                }
        }
        System.out.println("\n\n");
        aufnahmeDerDaten();
        }
    }

//findet heraus wie viel geld moch eingeworfen wird -Methode-
    private static void geldeinwurf(double zuZahlenderBetrag, double anzahlTickets) {
        
        Scanner tastatur = new Scanner(System.in);
        
        double eingezahlterGesamtbetrag = 0.0;
        
        zuZahlenderBetrag *=  anzahlTickets;
        while(eingezahlterGesamtbetrag< zuZahlenderBetrag){
            System.out.printf("%-15s%.2f", "Noch zu zahlen:", + (zuZahlenderBetrag - eingezahlterGesamtbetrag) );
            System.out.printf("%4s\n", "Euro");
            System.out.print("Eingabe (mind. 5Ct, höchstens 2 Euro):");
            double eingeworfeneMünze = tastatur.nextDouble();
            eingezahlterGesamtbetrag += eingeworfeneMünze;
            
            rückgabeberechnungUndAusgabe(eingezahlterGesamtbetrag, zuZahlenderBetrag);
        }
    }

//ausgabe des Fahrscheins -Methode-    
    private static void fahrscheinausgabe(){
        System.out.println("\nFahrschein wird ausgegeben");
        for (int i = 0; i < 8; i++){
            System.out.print("=");
            try{
                Thread.sleep(250);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        System.out.println("\n\n");
    }
    
//berechnung des fehlenden betrages oder berechnung des zurück zu gebenen betrages -Methode-
    private static void rückgabeberechnungUndAusgabe (double eingezahlterGesamtbetrag, double zuZahlenderBetrag){
        
        double rückgabebetrag = eingezahlterGesamtbetrag - zuZahlenderBetrag;
        
        if(rückgabebetrag > 0.0){
            
            System.out.println("Der Rückgabebetrag in Höhe von " + rückgabebetrag + " EURO");
            System.out.println("wird in folgenden Münzen ausgezahlt:");
            
            while(rückgabebetrag >= 2.0){       // 2 EURO-Münzen
                System.out.println("2 EURO");
                rückgabebetrag -= 2.0;
            }
            
            while(rückgabebetrag >= 1.0){       // 1 EURO-Münzen
                System.out.println("1 EURO");
                rückgabebetrag -= 1.0;
            }
            
            while(rückgabebetrag >= 0.5){       // 50 CENT-Münzen
                System.out.println("50 CENT");
                rückgabebetrag -= 0.5;
            }
            
            while(rückgabebetrag >= 0.2){       // 20 CENT-Münzen
                System.out.println("20 CENT");
                rückgabebetrag -= 0.2;
            }
            
            while(rückgabebetrag >= 0.1){       // 10 CENT-Münzen
                System.out.println("10 CENT");
                rückgabebetrag -= 0.1;
            }
            
            while(rückgabebetrag >= 0.05){      // 5 CENT-Münzen
                System.out.println("5 CENT");
                rückgabebetrag -= 0.05;
            }  
        }        
    }
}